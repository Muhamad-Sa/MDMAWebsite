document.addEventListener('DOMContentLoaded', () => {
    const slider = document.querySelector('.category-slider');
    const slideLeft = document.getElementById('slide-left');
    const slideRight = document.getElementById('slide-right');
    let currentPosition = 0;

    slideRight.addEventListener('click', () => {
        if (currentPosition > -3) {
            currentPosition--;
            slider.style.transform = `translateX(${currentPosition * 33.33}%)`;
        }
    });

    slideLeft.addEventListener('click', () => {
        if (currentPosition < 0) {
            currentPosition++;
            slider.style.transform = `translateX(${currentPosition * 33.33}%)`;
        }
    });
});
